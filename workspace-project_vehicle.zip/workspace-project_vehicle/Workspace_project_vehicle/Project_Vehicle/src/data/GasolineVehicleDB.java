package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import bus.EnumType;
import bus.GasVehicle;
import bus.RaiseException;


public class GasolineVehicleDB {
	
	static private Connection myConnection;
	static private String mySQLStatement = null;	
	static private String mySQLQuery = null;
	static private Statement myStatemnt = null;
	static private ResultSet myResultSet = null;
	static private GasVehicle aGasVehicle = null;
	/*
	 * return 1 if added successfully otherwise 0
	 */
	public static int insert(GasVehicle aNewGasVehicle) throws SQLException {
		myConnection = SingletonDBConnection.getConnection();		
		//Long serialNumber, String make, String model, Date dateOfManufacture, int tripCounter, EnumType type, double fuel
		mySQLStatement = "Insert into GasolineVehicle(SerialNumber, Make, Model, DateOfManufacture, TripCounter, FuelConsumed)  values( " 
																	+ aGasVehicle.getSerialNumber() + ", \'" 
                                                                    + aGasVehicle.getMake() + ", \'" 
                                                                    + aGasVehicle.getModel() + ", \'"
                                                                    + aGasVehicle.getDateOfManufacture() + ", \'"
                                                                    + aGasVehicle.getTripCounter() +  ", \'" 
                                                                    + aGasVehicle.getFuel() +  "\')";
		try {
			myStatemnt = myConnection.createStatement();
			int rowAffected = myStatemnt.executeUpdate(mySQLStatement);
			     myConnection.commit();			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public static int update(GasVehicle newGasVehicle) throws SQLException {
		
		myConnection = SingletonDBConnection.getConnection();
		
		mySQLStatement = "update GasolineVehicle set TripCounter =  \'"    
				
			                +   newGasVehicle.getTripCounter()  +  "\' WHERE SerialNumber = "
			                  
			                                                         +  newGasVehicle.getSerialNumber() ;
		
		try {
			
			myStatemnt = myConnection.createStatement();
			
			int rowAffected = myStatemnt.executeUpdate(mySQLStatement);
			
			    myConnection.commit();	
			    
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}			
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	/**
	 * 
	 * @param id primary key of vehicle
	 * @return	return 1 if removed successfully otherwise 0
	 * @throws SQLException
	 */
	public static int delete(Long serialNumber) throws SQLException {
		myConnection = SingletonDBConnection.getConnection();
		
		mySQLStatement = "Delete FROM GasolineVehicle WHERE SerialNumber = "  + serialNumber  ;
		
		try {
			myStatemnt = myConnection.createStatement();
			int rowAffected = myStatemnt.executeUpdate(mySQLStatement);
			
			myConnection.commit();	
			
				if(rowAffected > 0) {
					return 1;
				}else {
					return 0;
				}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public static GasVehicle search(Long serialNumber) throws SQLException, SQLException, NumberFormatException, RaiseException, ParseException{
		
		myConnection = SingletonDBConnection.getConnection();
		
		mySQLQuery = "SELECT SerialNumber, Make, Model, DateOfManufacture, TripCounter, FuelConsumed FROM GasolineVehicle WHERE SerialNumber = " + serialNumber ;
		
		myStatemnt = myConnection.createStatement();
		
		myResultSet = myStatemnt.executeQuery(mySQLQuery);
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		if(myResultSet.next()) {
			aGasVehicle = new GasVehicle(Long.parseLong(myResultSet.getString(1)), myResultSet.getString(2), myResultSet.getString(3), formatter.parse(myResultSet.getString(4)), Integer.parseInt(myResultSet.getString(5)), Double.parseDouble(myResultSet.getString(6)) );
		}		
		return aGasVehicle;
	}
	
	public static ArrayList<GasVehicle> select() throws SQLException, NumberFormatException, SQLException, RaiseException, ParseException{
		
		ArrayList<GasVehicle> myList = new ArrayList<GasVehicle>();
		
		myConnection = SingletonDBConnection.getConnection();
		
		mySQLQuery = "SELECT * FROM GasolineVehicle";
		
		myStatemnt = myConnection.createStatement();
		
		myResultSet = myStatemnt.executeQuery(mySQLQuery);
		
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		while(myResultSet.next()) {
			
			aGasVehicle = new GasVehicle(Long.parseLong(myResultSet.getString(1)), myResultSet.getString(2), myResultSet.getString(3), formatter.parse(myResultSet.getString(4)), Integer.parseInt(myResultSet.getString(5)), Double.parseDouble(myResultSet.getString(6)) );
			
			myList.add(aGasVehicle);
		}
		
		return myList;
	}
}