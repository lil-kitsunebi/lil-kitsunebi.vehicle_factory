package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import bus.ElectricVehicle;
import bus.RaiseException;

public class ElectricVehicleDB {
	static private Connection myConnection;
	static private String mySQLStatement = null;	
	static private String mySQLQuery = null;
	static private Statement myStatemnt = null;
	static private ResultSet myResultSet = null;
	static private ElectricVehicle aElectricVehicle = null;
	/*
	 * return 1 if added successfully otherwise 0
	 */
	public static int insert(ElectricVehicle aNewElectricVehicle) throws SQLException {
		myConnection = SingletonDBConnection.getConnection();		
		mySQLStatement = "Insert into ElectricVehicle(SerialNumber, Make, Model, DateOfManufacture, TripCounter, KwPowerConsumed)  values( " 
																	+ aElectricVehicle.getSerialNumber() + ", \'" 
																	+ aElectricVehicle.getMake() + ", \'" 
																	+ aElectricVehicle.getModel() + ", \'"
																	+ aElectricVehicle.getDateOfManufacture() + ", \'"
																	+ aElectricVehicle.getTripCounter() +  ", \'" 
																	+ aElectricVehicle.getKw() +  "\')";
		try {	
			myStatemnt = myConnection.createStatement();
			int rowAffected = myStatemnt.executeUpdate(mySQLStatement);
			     myConnection.commit();			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public static int update(ElectricVehicle newElectricVehicle) throws SQLException {
		
		myConnection = SingletonDBConnection.getConnection();
		
		mySQLStatement = "update ElectricVehicle set TripCounter =  \'"    
				
			                +   newElectricVehicle.getTripCounter()  +  "\' WHERE  SerialNumber = "
			                  
			                                                         +  newElectricVehicle.getSerialNumber() ;
		
		try {
			
			myStatemnt = myConnection.createStatement();
			
			int rowAffected = myStatemnt.executeUpdate(mySQLStatement);
			
			    myConnection.commit();	
			    
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}			
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	/**
	 * 
	 * @param id primary key of vehicle
	 * @return	return 1 if removed successfully otherwise 0
	 * @throws SQLException
	 */
	public static int delete(Long serialNumber) throws SQLException {
		myConnection = SingletonDBConnection.getConnection();
		
		mySQLStatement = "Delete FROM ElectricVehicle WHERE SerialNumber = "  + serialNumber  ;
		
		try {
			myStatemnt = myConnection.createStatement();
			int rowAffected = myStatemnt.executeUpdate(mySQLStatement);
			
			myConnection.commit();	
			
				if(rowAffected > 0) {
					return 1;
				}else {
					return 0;
				}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public static ElectricVehicle search(Long serialNumber) throws SQLException, SQLException, NumberFormatException, RaiseException, ParseException{
		
		myConnection = SingletonDBConnection.getConnection();
		
		mySQLQuery = "SELECT SerialNumber, Make, Model, DateOfManufacture, TripCounter, KwPowerConsumed FROM ElectricVehicle WHERE SerialNumber = " + serialNumber ;
		
		myStatemnt = myConnection.createStatement();
		
		myResultSet = myStatemnt.executeQuery(mySQLQuery);
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		
		if(myResultSet.next()) {
			aElectricVehicle = new ElectricVehicle(Long.parseLong(myResultSet.getString(1)), myResultSet.getString(2), myResultSet.getString(3), formatter.parse(myResultSet.getString(4)), Integer.parseInt(myResultSet.getString(5)), Double.parseDouble(myResultSet.getString(6)) );
		}		
		return aElectricVehicle;
	}
	
	public static ArrayList<ElectricVehicle> select() throws SQLException, NumberFormatException, SQLException, RaiseException, ParseException{
		
		ArrayList<ElectricVehicle> myList = new ArrayList<ElectricVehicle>();
		
		myConnection = SingletonDBConnection.getConnection();
		
		mySQLQuery = "SELECT * FROM ElectricVehicle";
		
		myStatemnt = myConnection.createStatement();
		
		myResultSet = myStatemnt.executeQuery(mySQLQuery);
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		
		
		while(myResultSet.next()) {
			
			aElectricVehicle = new ElectricVehicle(Long.parseLong(myResultSet.getString(1)), myResultSet.getString(2), myResultSet.getString(3), formatter.parse(myResultSet.getString(4)), Integer.parseInt(myResultSet.getString(5)), Double.parseDouble(myResultSet.getString(6)) );
			
			myList.add(aElectricVehicle);
		}
		
		return myList;
	}
}