package client;

import java.sql.SQLException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

import bus.ElectricVehicle;
import bus.FileManager;
import bus.FileManager2;
import bus.GasVehicle;
import bus.MileageEfficiencyComparator;
import bus.RaiseException;
import bus.SerialNumberComparator;
import bus.SingletonCollection;
import bus.SingletonHashMapCollection;
import bus.Vehicle;
import bus.VehicleFactory;

public class ApplicationTester {
	public static void add(Scanner scan, Vehicle vehicle, int type) throws RaiseException { 		
	    if(type==1) {
	    	GasVehicle gv = new GasVehicle();	//gv = gas vehicle
    	      	gv = (GasVehicle)vehicle; //downcasting
			
			boolean valid = false;		
			do
			{
				try
				{
					System.out.print("Enter the serial number (must only be numbers): ");				
					gv.setSerialNumber(scan.nextLong());
					valid =  true;				
				}
				catch(RaiseException ex)
				{
					System.out.println(ex.getMessage());				
				}	
			}while(!valid);
 
			valid = false;
			do
			{
				try
				{
					System.out.print("Enter the make (must only be alphabetic letters): ");				
					gv.setMake(scan.next());
					valid =  true;				
				}
				catch(RaiseException ex)
				{
					System.out.println(ex.getMessage());				
				}	
			}while(!valid);
			
			valid = false;
			do
			{
				try
				{
					System.out.print("Enter the model (must only be alphabetic letters): ");				
					gv.setModel(scan.next());
					valid =  true;				
				}
				catch(RaiseException ex)
				{
					System.out.println(ex.getMessage());				
				}	
			}while(!valid);
			
		//Date of manufacture
			DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
			System.out.print("Enter the date of manufacture (YYYY/MM/DD): ");				
			try {
				gv.setDateOfManufacture(formatter.parse(scan.next()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}				
	
			
			valid = false;
			do
			{
				try
				{
					System.out.print("Enter the trip counter: ");				
					gv.setTripCounter(scan.nextInt());
					valid =  true;				
				}
				catch(RaiseException ex)
				{
					System.out.println(ex.getMessage());				
				}	
			}while(!valid);
			
			valid = false;
			do
			{
				try
				{
					System.out.print("Enter the fuel consumed: ");				
					gv.setFuel(scan.nextDouble());
					valid =  true;				
				}
				catch(RaiseException ex)
				{
					System.out.println(ex.getMessage());				
				}	
			}while(!valid);
	    	
		    //gv.makeTrip(tripCounter, fuel);
		     
		           VehicleFactory.add((Vehicle) gv);  //upcasting
		           SingletonCollection.getSingleInstance().add(gv);
		           SingletonHashMapCollection.getSingleInstance().add( gv.getSerialNumber() , gv); 
	    }
	    else if(type==2) {
	    	ElectricVehicle ev = new ElectricVehicle();	//ev = electric vehicle
	    			ev = (ElectricVehicle)vehicle; //downcasting 
	    	
	    	boolean valid = false;		
	    	do
	    	{
	    		try
	    		{
	    			System.out.print("Enter the serial number (must only be number): ");				
	    			ev.setSerialNumber(scan.nextLong());
	    			valid =  true;				
	    		}
	    		catch(RaiseException ex)
	    		{
	    			System.out.println(ex.getMessage());				
	    		}	
	    	}while(!valid);
	    		
	    	valid = false;
			do
			{
				try
				{
					System.out.print("Enter the make (must only be alphabetic letters): ");				
					ev.setMake(scan.next());
					valid =  true;				
				}
				catch(RaiseException ex)
				{
					System.out.println(ex.getMessage());				
				}	
			}while(!valid);
			
			valid = false;
			do
			{
				try
				{
					System.out.print("Enter the model (must only be alphabetic letters): ");				
					ev.setModel(scan.next());
					valid =  true;				
				}
				catch(RaiseException ex)
				{
					System.out.println(ex.getMessage());				
				}	
			}while(!valid);
			
		//Date of manufacture
			DateFormat formatter = new SimpleDateFormat("YYYY/MM/DD");
			System.out.print("Enter the date of manufacture (YYYY/MM/DD): ");				
			try {
				ev.setDateOfManufacture(formatter.parse(scan.next()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
	    	
	    	
	    	valid = false;
	    	do
	    	{
	    		try
	    		{
	    			System.out.print("Enter the trip counter: ");				
	    			ev.setTripCounter(scan.nextInt());
	    			valid =  true;				
	    		}
	    		catch(RaiseException ex)
	    		{
	    			System.out.println(ex.getMessage());				
	    		}	
	    	}while(!valid);
	    			
	    	valid = false;
	    	do
	    	{
	    		try
	    		{
	    			System.out.print("Enter the fuel consumed: ");				
	    			ev.setKw(scan.nextDouble());
	    			valid =  true;				
	    		}
	    		catch(RaiseException ex)
	    		{
	    			System.out.println(ex.getMessage());				
	    		}	
	    	}while(!valid);
		    
		     		VehicleFactory.add((Vehicle) ev);//upcasting
		     		SingletonCollection.getSingleInstance().add(ev);
		     		SingletonHashMapCollection.getSingleInstance().add( ev.getSerialNumber() , ev);
	    }	
	}

	public static void loadData(Scanner scan) throws RaiseException {    
		  int option;
	      int keepLooping = 0;
	      
		  do {
			  GasVehicle gv= new GasVehicle();
			  ElectricVehicle ev= new ElectricVehicle();
			  int type;
			  
			  System.out.print("\nWhat type of counter?(1-gas vehicle , 2-electric vehicle): ");		
			  option = scan.nextInt();
			
			  switch(option) {
			  	case 1:
			  		type=1;
				    add(scan, gv, type);
				    break;
				
				case 2: 
					type=2;
					add(scan , ev, type);
					break;
			}
			
			  System.out.print("Do you want to continue adding vehicles? (type 1-to continue, any key to stop): ");
			  keepLooping = scan.nextInt();
			
		  }while (keepLooping == 1);		
	}
	
	public static void main(String[] args) throws RaiseException, ClassNotFoundException, IOException, SQLException, NumberFormatException, ParseException {
		
		Scanner scan = new Scanner(System.in);	
		int option;
	    int keepLooping = 0;
	      
		  do {
			  System.out.print("\nWhat do you want to do?\n1-Add a vehicle\n2-Show the list of vehicles from RAM and from Hard Drive\n3-Search for a vehicle\n4-Sort the vehicles by their serial number and mileage efficiency\n5-SQL\n");		
			  option = scan.nextInt();
			
			  switch(option) {
			  	case 1:
			  		//loading data during run-time
			        loadData(scan);
				    break;
				
				case 2: 
					System.out.println("\n --  List of vehicles from RAM");
					for(Vehicle aVehicle :  SingletonHashMapCollection.getSingleInstance().getListOfVehicles().values())
					{
						System.out.println(aVehicle);			
					}
					
						
					System.out.println("\n WRITE TO FILE");
					FileManager2.writeToSerializedFile(
							                  (HashMap<Long, Vehicle>) (SingletonHashMapCollection.getSingleInstance().getListOfVehicles())
							                        );


					System.out.println("\n READ FROM FILE");	
					System.out.println("\n List of vehicles from Hard Drive");
					for(Vehicle aVehicle : FileManager2.readFromSerializedFile().values())
					{
						System.out.println(aVehicle);			
					}
					break;
				case 3: 
					Long key;
					System.out.print("\nSearching for a vehicle: \n\t Enter the key(serial number): ");
					key = scan.nextLong();
					  
		           //System.out.println("\t" + SingletonCollection2.getSingleInstance().search(key));
					  
					ArrayList<Vehicle> vehiclesList = SingletonHashMapCollection.getSingleInstance().search2(key);
					
					if (vehiclesList == null)
					{
						System.out.println("Serial number " + key + "   not found" );
					}
				   else 
				   {
					   for(Vehicle aCity : vehiclesList)
					   {
					   System.out.println("Serial number " + key + " found" + " - "  + aCity) ;
					   }
					}
					break;
				case 4: 
					ArrayList <Vehicle> sortingList = new ArrayList<Vehicle>(  SingletonHashMapCollection.getSingleInstance().getListOfVehicles().values()  );
					  
			        Collections.sort(sortingList, new SerialNumberComparator() );
					System.out.println("\n List of vehicles sorted by serial number");
					for(Vehicle aVehicle :  sortingList)
					{
					System.out.println(aVehicle);			
					}
					
					Collections.sort(sortingList, new MileageEfficiencyComparator());
					System.out.println("\n List of vehicles sorted by mileage efficiency");
					for(Vehicle aVehicle :  sortingList)
					{
					System.out.println(aVehicle);			
					}
					break;
				case 5:
					Scanner scanSQL = new Scanner(System.in);	
					int optionSQL;
				    int keepLoopingSQL = 0;
				    
				    ArrayList<GasVehicle> gasVehicleList = new ArrayList<>();
				    GasVehicle     searchedGasVehicle =  new GasVehicle();		
					GasVehicle     aGasVehicle =  null;
					Long GSerialNumber; String GMake;	String GModel; Date GDateOfManufacture; int GTripCounter; 	double GFuel;
					
					ArrayList<ElectricVehicle> electricVehicleList = new ArrayList<>();
				    ElectricVehicle     searchedElectricVehicle =  new ElectricVehicle();		
					ElectricVehicle     aElectricVehicle =  null;
					Long ESerialNumber; String EMake;	String EModel; Date EDateOfManufacture; int ETripCounter; 	double EKw;
				    
					  do {
						  System.out.print("\nWhat do you want to do?\n1-Querying the database\n2-Searching for a Gasoline Vehicle by serial number\n3-Searching for a Electric Vehicle by serial number\n4-Update data into Gasoline Vehicle database\n5-Update data into Electric Vehicle database\n6-Insert data into Gasoline Vehicle database\n7-Insert data into Gasoline Vehicle database\n");		
						  optionSQL = scanSQL.nextInt();
						
						  switch(optionSQL) {
						  	case 1:
						  		System.out.println("... Querying the database: GasolineVehicle database.... ");
						      	gasVehicleList  = GasVehicle.getData();	 		
						      	for (GasVehicle current : gasVehicleList)
						      	{
						      		System.out.println(current);			
						      	}	
						      	System.out.println("\n... Querying the database: ElectricVehicle database.... ");
						      	electricVehicleList  = ElectricVehicle.getData();	 		
						      	for (ElectricVehicle current : electricVehicleList)
						      	{
						      		System.out.println(current);			
						      	}	
						  		break;
						  	case 2:
						  		System.out.println("... Searching for a Gasoline Vehicle by serial number .... ");
								 GSerialNumber =(long) 0 ; GMake = null; GModel = null; GDateOfManufacture = null; GTripCounter = 0; GFuel = (double)0;
								    searchedGasVehicle = null ;			 
								System.out.print("Enter serial number to search for: ");
								GSerialNumber = scanSQL.nextLong();		
								searchedGasVehicle = new GasVehicle();
								    
								searchedGasVehicle = GasVehicle.search(GSerialNumber);	
								    
								        System.out.println( "GasolineVehicle"  +  searchedGasVehicle) ;	
						  		break;
						  	case 3:
						  		System.out.println("... Searching for an Electric Vehicle by serial number .... ");
								 ESerialNumber =(long) 0 ; EMake = null; EModel = null; EDateOfManufacture = null; ETripCounter = 0; EKw = (double)0;
								    searchedElectricVehicle = null ;			 
								System.out.print("Enter serial number to search for: ");
								ESerialNumber = scanSQL.nextLong();		
								searchedElectricVehicle = new ElectricVehicle();
								    
								searchedElectricVehicle = ElectricVehicle.search(ESerialNumber);	
								    
								        System.out.println( "ElectricVehicle"  +  searchedElectricVehicle) ;	
						  		break;
						  	case 4:
						  		GSerialNumber =(long) 0 ; GMake = null; GModel = null; GDateOfManufacture = null; GTripCounter = 0; GFuel = (double)0;
								System.out.println("Enter the Gasoline Vehicle serial number to update: ");
								GSerialNumber = scan.nextLong();
								        scan.nextLine();  // C++ : cin.ignore() 
								        
								System.out.println("Enter the new tripCounter : ");
								GTripCounter = scan.nextInt();
								
										aGasVehicle = new GasVehicle();
										aGasVehicle.setSerialNumber(GSerialNumber);
										aGasVehicle.setTripCounter(GTripCounter);	
										
										GasVehicle.update(aGasVehicle);              
						  		break;
						  	case 5:
						  		ESerialNumber =(long) 0 ; EMake = null; EModel = null; EDateOfManufacture = null; ETripCounter = 0; EKw = (double)0;
								System.out.println("Enter the Electric Vehicle serial number to update: ");
								ESerialNumber = scan.nextLong();
								        scan.nextLine();  // C++ : cin.ignore() 
								        
								System.out.println("Enter the new tripCounter : ");
								ETripCounter = scan.nextInt();
								
										aElectricVehicle = new ElectricVehicle();
										aElectricVehicle.setSerialNumber(ESerialNumber);
										aElectricVehicle.setTripCounter(ETripCounter);	
										
										ElectricVehicle.update(aElectricVehicle);              
						  		break;
						  	case 6:
						  		GSerialNumber =(long) 0 ; GMake = null; GModel = null; GDateOfManufacture = null; GTripCounter = 0; GFuel = (double)0;
								System.out.println("Gasoline Vehicle serial number : ");
								GSerialNumber = scan.nextLong();		
								        scan.nextLine();  // C++ : cin.ignore()		
								System.out.println("Make : ");
								GMake = scan.next();		
								System.out.println("Model : ");
								GModel = scan.next();	
								DateFormat formatter = new SimpleDateFormat("YYYY/MM/DD");
								System.out.println("Date of manufacture : ");
								GDateOfManufacture = formatter.parse(scan.next());	
								System.out.println("TripCounter : ");
								GTripCounter = scan.nextInt();	
								System.out.println("Fuel consumed : ");
								GFuel = scan.nextDouble();
								
								aGasVehicle = new GasVehicle();
								aGasVehicle.setSerialNumber(GSerialNumber);
								aGasVehicle.setMake(GMake);
								aGasVehicle.setModel(GModel);
								aGasVehicle.setDateOfManufacture(GDateOfManufacture);
								aGasVehicle.setTripCounter(GTripCounter);	
								aGasVehicle.setFuel(GFuel);
								GasVehicle.add(aGasVehicle);
						  		break;
						  	case 7:
						  		ESerialNumber =(long) 0 ; EMake = null; EModel = null; EDateOfManufacture = null; ETripCounter = 0; EKw = (double)0;
								System.out.println("Electric Vehicle serial number : ");
								ESerialNumber = scan.nextLong();		
								        scan.nextLine();  // C++ : cin.ignore()		
								System.out.println("TripCounter : ");
								ETripCounter = scan.nextInt();		
								
								aElectricVehicle = new ElectricVehicle();
								aElectricVehicle.setSerialNumber(ESerialNumber);
								aElectricVehicle.setSerialNumber(ESerialNumber);
								aElectricVehicle.setMake(EMake);
								aElectricVehicle.setModel(EModel);
								aElectricVehicle.setDateOfManufacture(EDateOfManufacture);
								aElectricVehicle.setTripCounter(ETripCounter);		
								aElectricVehicle.setKw(EKw);
								ElectricVehicle.add(aElectricVehicle);
						  		break;
						  	}
						  System.out.print("Do you want to return to the SQL menu? (type 1-to continue, any key to return to the main menu): ");
						  keepLoopingSQL = scan.nextInt();
						  
						  }while(keepLoopingSQL == 1);
			  }
			  
			  System.out.print("Do you want to return to the main menu? (type 1-to continue, any key to quit): ");
			  keepLooping = scan.nextInt();
			
		  }while (keepLooping == 1);		
		

//        //SingletonCollection
//        System.out.print("\n--- List of vehicles from RAM ---\n");
//		for(Vehicle aVehicle : SingletonCollection.getSingleInstance().getListOfVehicles())
//		{
//			System.out.println(aVehicle);			
//		}
//		
//		//FileManager
//		FileManager.writeToSerializedFile(SingletonCollection.getSingleInstance().getListOfVehicles());
//				   		
//		System.out.println("\n--- List of cities from Hard Drive ---\n");
//		for(Vehicle aVehicle : FileManager.readFromSerializedFile())
//		{
//		   	System.out.println(aVehicle);			
//		}
//		
//		//printing data with VehiclesFleet
//		System.out.println("\n--- List of gas vehicles ---");		
//		for(GasVehicle item : VehicleFactory.getGasVehicleList()) {
//			System.out.println(item.toString());			
//		}
//				
//		System.out.println("\n--- List of electric vehicles ---");		
//		for(ElectricVehicle item : VehicleFactory.getElectricVehicleList()) {
//			System.out.println(item.toString());			
//		}
//		
//		//Sorting
//		//by serial number
//		SingletonCollection.getSingleInstance().sort(new SerialNumberComparator());
//
//		System.out.println("\n--- List of vehicles sorted by serial number ---");
//		for(Vehicle aVehicle :  SingletonCollection.getSingleInstance().getListOfVehicles())
//		{
//			System.out.println(aVehicle);			
//		}
//
//		//by mileage
//		SingletonCollection.getSingleInstance().sort(new MileageEfficiencyComparator());
//
//		System.out.println("\n--- List of vehicles sorted by mileage efficiency ---");
//		for(Vehicle aVehicle :  SingletonCollection.getSingleInstance().getListOfVehicles())
//		{
//			System.out.println(aVehicle);			
//		}
//
//		//Search with SingleCollection
////		String key;
////		System.out.print("\n--- Searching for a vehicle--- \n\t Enter the key(serial number): ");
////		  key = scan.nextLine();		
////		           System.out.println("\t" + SingletonCollection.getSingleInstance().search(key));
//		
//		//Search with VehicleFleet
//		String key;
//		Vehicle searchedVehicle = null;
//		int again;
//			    
//		do {
//			System.out.println("\n--- Searching for a Vehicle (by serial number) --- ");
//			System.out.print("Enter the serial number: ");
//			key = scan.next();		
//					
//			searchedVehicle = VehicleFactory.search(key);
//					
//			if(searchedVehicle == null) {
//			  	System.out.println("Vehicle NOT found...");
//			}
//			else {
//				System.out.println("Vehicle found..."  + searchedVehicle.toString());				
//			}
//				System.out.println("continue ? (type 1 otherwise type 0)");
//				again = scan.nextInt();	
//					
//			}while(again == 1);
		           
	
		scan.close();
		System.exit(0);
	}
}





/*
What do you want to do?
1-Add a vehicle
2-Show the list of vehicles from RAM and from Hard Drive
3-Search for a vehicle
4-Sort the vehicles by their serial number and mileage efficiency
5-SQL
1

What type of counter?(1-gas vehicle , 2-electric vehicle): 1
Enter the serial number (must only be numbers): 123
Enter the make (must only be alphabetic letters): honda
Enter the model (must only be alphabetic letters): civic
Enter the date of manufacture (YYYY/MM/DD): 2020/01/01
Enter the trip counter: 10
Enter the fuel consumed: 7,7
Do you want to continue adding vehicles? (type 1-to continue, any key to stop): 1

What type of counter?(1-gas vehicle , 2-electric vehicle): 2
Enter the serial number (must only be number): 456
Enter the make (must only be alphabetic letters): volk1
invalid input- value must be only an alphabet letter
Enter the make (must only be alphabetic letters): volkswagen
Enter the model (must only be alphabetic letters): tiguan
Enter the date of manufacture (YYYY/MM/DD): 2021/03/03
Enter the trip counter: 2
Enter the fuel consumed: 2,2
Do you want to continue adding vehicles? (type 1-to continue, any key to stop): 0
Do you want to return to the main menu? (type 1-to continue, any key to quit): 1

What do you want to do?
1-Add a vehicle
2-Show the list of vehicles from RAM and from Hard Drive
3-Search for a vehicle
4-Sort the vehicles by their serial number and mileage efficiency
5-SQL
2

 --  List of vehicles from RAM
456 - volkswagen - tiguan - Sun Dec 27 00:00:00 EST 2020 - Trip counter: 2 - ElectricVehicle [kwPowerConsumed=2.2, mileage=0.9090909090909091]
123 - honda - civic - Sun Dec 29 00:00:00 EST 2019 - Trip counter: 10 - GasVehicle [fuelConsumed=7.7, mileage=1.2987012987012987]

 WRITE TO FILE

 READ FROM FILE

 List of vehicles from Hard Drive
456 - volkswagen - tiguan - Sun Dec 27 00:00:00 EST 2020 - Trip counter: 2 - ElectricVehicle [kwPowerConsumed=2.2, mileage=0.9090909090909091]
123 - honda - civic - Sun Dec 29 00:00:00 EST 2019 - Trip counter: 10 - GasVehicle [fuelConsumed=7.7, mileage=1.2987012987012987]
Do you want to return to the main menu? (type 1-to continue, any key to quit): 1

What do you want to do?
1-Add a vehicle
2-Show the list of vehicles from RAM and from Hard Drive
3-Search for a vehicle
4-Sort the vehicles by their serial number and mileage efficiency
5-SQL
3

Searching for a vehicle: 
	 Enter the key(serial number): 123
Serial number 123 found - 123 - honda - civic - Sun Dec 29 00:00:00 EST 2019 - Trip counter: 10 - GasVehicle [fuelConsumed=7.7, mileage=1.2987012987012987]
Do you want to return to the main menu? (type 1-to continue, any key to quit): 1

What do you want to do?
1-Add a vehicle
2-Show the list of vehicles from RAM and from Hard Drive
3-Search for a vehicle
4-Sort the vehicles by their serial number and mileage efficiency
5-SQL
4

 List of vehicles sorted by serial number
123 - honda - civic - Sun Dec 29 00:00:00 EST 2019 - Trip counter: 10 - GasVehicle [fuelConsumed=7.7, mileage=1.2987012987012987]
456 - volkswagen - tiguan - Sun Dec 27 00:00:00 EST 2020 - Trip counter: 2 - ElectricVehicle [kwPowerConsumed=2.2, mileage=0.9090909090909091]

 List of vehicles sorted by mileage efficiency
456 - volkswagen - tiguan - Sun Dec 27 00:00:00 EST 2020 - Trip counter: 2 - ElectricVehicle [kwPowerConsumed=2.2, mileage=0.9090909090909091]
123 - honda - civic - Sun Dec 29 00:00:00 EST 2019 - Trip counter: 10 - GasVehicle [fuelConsumed=7.7, mileage=1.2987012987012987]
Do you want to return to the main menu? (type 1-to continue, any key to quit): 1

What do you want to do?
1-Add a vehicle
2-Show the list of vehicles from RAM and from Hard Drive
3-Search for a vehicle
4-Sort the vehicles by their serial number and mileage efficiency
5-SQL
5

What do you want to do?
1-Querying the database
2-Searching for a Gasoline Vehicle by serial number
3-Searching for a Electric Vehicle by serial number
4-Update data into Gasoline Vehicle database
5-Update data into Electric Vehicle database
6-Insert data into Gasoline Vehicle database
7-Insert data into Gasoline Vehicle database
5
Enter the Electric Vehicle serial number to update: 
202
Enter the new tripCounter : 
8
 Connection successful
Do you want to return to the SQL menu? (type 1-to continue, any key to return to the main menu): 0
Do you want to return to the main menu? (type 1-to continue, any key to quit): 0
*/