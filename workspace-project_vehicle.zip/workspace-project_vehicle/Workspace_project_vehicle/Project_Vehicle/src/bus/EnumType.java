package bus;

public enum EnumType {
	GasVehicle, ElectricVehicle, Undefined
}
