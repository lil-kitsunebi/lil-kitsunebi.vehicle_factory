package bus;

import java.util.ArrayList;
import java.util.Collections;

public class VehicleFactory {

	//private data
	private static ArrayList <Vehicle> vehicleList = new ArrayList<Vehicle>();
	
	public static void setVehicleList(ArrayList<Vehicle> vehicleList) {
		VehicleFactory.vehicleList = vehicleList;
	}
	
	//public services
		public static ArrayList<Vehicle> getVehicleList() {
			return vehicleList;
		}	
		
		public static ArrayList<GasVehicle> getGasVehicleList() {
			ArrayList <GasVehicle>  gasList = new ArrayList<GasVehicle>();
			for(Vehicle item : vehicleList)
			{
				if(item instanceof GasVehicle)
				{
					gasList.add((GasVehicle)item);				
				}		
			}
			return gasList;
		}
		
		public static ArrayList<ElectricVehicle> getElectricVehicleList() {
			ArrayList <ElectricVehicle>  electricList = new ArrayList<ElectricVehicle>();
			for(Vehicle item : vehicleList)
			{
				if(item instanceof ElectricVehicle)
				{
					electricList.add((ElectricVehicle)item);				
				}		
			}
			 return electricList;
		}
		
		
		public static void add(Vehicle object)	{
			vehicleList.add(object);
		}	
		
		public static void remove(Vehicle object)	{
			vehicleList.remove(object);		
		}
		
		public static Vehicle search(Long key )
		{
			Vehicle searchedVehicle = null;
			
			for(Vehicle aVehicle : vehicleList)
			{				
				if(  aVehicle.getSerialNumber().equals(key)    )
				{
					searchedVehicle = aVehicle;
					break;
				}				
			}		
			return searchedVehicle;
		}	
		
		public static void Sort(SerialNumberComparator predict)	{
			 Collections.sort(vehicleList   ,   predict  );
		}
		public static void Sort(MileageEfficiencyComparator predict)	{
			 Collections.sort(vehicleList   ,   predict );
		}
		
		public static void SortBySerialNumber()	{
			 Collections.sort(vehicleList   ,   new SerialNumberComparator()  );
		}
		public static void SortByMileageEfficiency()	{
			 Collections.sort(vehicleList   ,   new MileageEfficiencyComparator()  );
		}
}
