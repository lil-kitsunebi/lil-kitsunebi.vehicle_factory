package bus;

public class Validator {	
	public static void isAlphabetic(String value) throws RaiseException
	{
		for(int i = 0 ; i != value.length() ; i++)
		{
			
			if(  !Character.isAlphabetic(value.charAt(i)))
			{
				throw new RaiseException("invalid input- value must be only an alphabet letter");			
			}		
		}		
	}
	
	public static void isPositiveLong(long value) throws RaiseException
	{
		if( value <= 0)
		{			
			throw new RaiseException("invalid input - data must be positive");
			
		}
		
	}
	
	public static void isPositiveInt(int value) throws RaiseException
	{
		if( value <= 0)
		{			
			throw new RaiseException("invalid input - data must be positive");
			
		}
		
	}
	
	public static void isPositiveDouble(double value) throws RaiseException
	{
		if( value <= 0)
		{			
			throw new RaiseException("invalid input - data must be positive");
			
		}
		
	}
	

}