package bus;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class FileManager2 {
private static String filePath = "src//data//vehicls-file.ser" ;
	
	public static void writeToSerializedFile(HashMap<Long, Vehicle>  collection) throws IOException
	{		 
		ArrayList<Vehicle> arrayList = new ArrayList <> (     ((HashMap<Long, Vehicle>) collection).values()    );
		
		FileOutputStream fos = new FileOutputStream(filePath);		
		ObjectOutputStream oos = new ObjectOutputStream(fos);	
		
		  oos.writeObject(arrayList);		  
		  fos.close();		
	}	

	public static HashMap<Long, Vehicle>  readFromSerializedFile() throws IOException, ClassNotFoundException
	{
		HashMap<Long, Vehicle> vehiclesHashMap = new HashMap<Long, Vehicle>();		
		ArrayList< Vehicle> vehiclesArrayList    = new ArrayList<Vehicle>();
		
		  FileInputStream fis = new FileInputStream(filePath);		  
		  ObjectInputStream ois = new ObjectInputStream(fis);		  
		  
		  vehiclesArrayList  =   (ArrayList<Vehicle>) ois.readObject();
		  
		  for(Vehicle aVehicle :  vehiclesArrayList)  {
			  
			  vehiclesHashMap.put(aVehicle.getSerialNumber(), aVehicle);
		  }		  
		  fis.close();			  
		  return vehiclesHashMap;	
	} 	
}