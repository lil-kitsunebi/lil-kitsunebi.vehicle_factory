package bus;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import data.ElectricVehicleDB;

public class ElectricVehicle extends Vehicle{

	private static final long serialVersionUID = 1L;
	private double kwPowerConsumed;
	
	public ElectricVehicle()
	{
		super();
		this.kwPowerConsumed = 2.22;
	}
	
	//public ElectricVehicle(Long serialNumber, String make, String model, Date dateOfManufacture, int tripCounter, EnumType type, double kw) throws RaiseException
	public ElectricVehicle(Long serialNumber, String make, String model, Date dateOfManufacture, int tripCounter, double kw) throws RaiseException
	{
		//super(serialNumber, make, model, dateOfManufacture, tripCounter, type);
		super(serialNumber, make, model, dateOfManufacture, tripCounter);
		this.setKw(kw);
	}
	
	public double getKw() {
		return kwPowerConsumed;
	}
	public void setKw(double kw) throws RaiseException {
		Validator.isPositiveDouble(kwPowerConsumed);
		this.kwPowerConsumed = kw;
	}
	
	@Override
	public double getMilePerUnitOfEnergy()
	{
		return this.getTripCounter()/this.kwPowerConsumed;
	}
	
	@Override
	public void makeTrip(int tripCounter, double energyConsumed) throws RaiseException
	{
		super.setTripCounter(tripCounter);
		this.kwPowerConsumed = energyConsumed;
	}
	
	@Override
	public String toString()
	{
		return super.getSerialNumber() + " - " + super.getMake() + " - " + super.getModel() + " - " + super.getDateOfManufacture() + " - Trip counter: " + this.getTripCounter() + " - " + "ElectricVehicle [kwPowerConsumed=" + kwPowerConsumed + ", mileage=" + this.getMilePerUnitOfEnergy() + "]";
	}
	
	//public static services
			public static int add(ElectricVehicle element) throws SQLException {
				return ElectricVehicleDB.insert(element);
			}
			
			public static int update(ElectricVehicle element) throws SQLException {
				return ElectricVehicleDB.update(element);
			}
			
			public static int remove(Long id) throws SQLException {
				return ElectricVehicleDB.delete(id);
			}
			
			public static ElectricVehicle search(Long id) throws SQLException, SQLException, NumberFormatException, RaiseException, ParseException {
				return ElectricVehicleDB.search(id);
			}
			
			public static ArrayList<ElectricVehicle> getData() throws SQLException, SQLException, NumberFormatException, RaiseException, ParseException {
				return ElectricVehicleDB.select();
			}
}
