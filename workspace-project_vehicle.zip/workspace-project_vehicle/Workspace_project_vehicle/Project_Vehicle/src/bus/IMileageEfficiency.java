package bus;

public interface IMileageEfficiency {
	
	public abstract double getMilePerUnitOfEnergy();
	public abstract void makeTrip();
	public abstract void makeTrip(int tripCounter, double energyConsumed) throws RaiseException;
}
