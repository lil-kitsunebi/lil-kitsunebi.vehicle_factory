package bus;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class FileManager {	
	
	private static String filePath = "src//data//vehicles-file.ser" ;

	public static void writeToSerializedFile(ArrayList<Vehicle> vehicleList) throws IOException
	{		
		FileOutputStream fos = new FileOutputStream(filePath);
		ObjectOutputStream oos = new ObjectOutputStream(fos);		
		
		  oos.writeObject(vehicleList);
		  fos.close();		
	}	

	public static ArrayList <Vehicle>  readFromSerializedFile() throws IOException, ClassNotFoundException
	{
		ArrayList<Vehicle> vehicleListFromFile = new ArrayList<Vehicle>();
		  FileInputStream fis = new FileInputStream(filePath);
		  ObjectInputStream ois = new ObjectInputStream(fis);		  
		  vehicleListFromFile  =   (ArrayList<Vehicle>) ois.readObject();		  
		  fis.close();			  
		  return vehicleListFromFile;	
	} 	

}
