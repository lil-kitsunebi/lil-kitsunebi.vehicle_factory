package bus;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import data.GasolineVehicleDB;

public class GasVehicle extends Vehicle{

	private static final long serialVersionUID = 1L;
	private double fuelConsumed;

	public GasVehicle()
	{
		super();
		this.fuelConsumed = 7.77;
	}
	
	//public GasVehicle(Long serialNumber, String make, String model, Date dateOfManufacture, int tripCounter, EnumType type, double fuel) throws RaiseException
	public GasVehicle(Long serialNumber, String make, String model, Date dateOfManufacture, int tripCounter, double fuel) throws RaiseException
	{
		//super(serialNumber, make, model, dateOfManufacture, tripCounter, type);
		super(serialNumber, make, model, dateOfManufacture, tripCounter);
		this.setFuel(fuel);
	}
	
	public double getFuel() {
		return fuelConsumed;
	}
	public void setFuel(double fuel) throws RaiseException {
		Validator.isPositiveDouble(fuelConsumed);
		this.fuelConsumed = fuel;
	}
	
	@Override
	public double getMilePerUnitOfEnergy()
	{
		return this.getTripCounter()/this.fuelConsumed;
	}

	@Override
	public void makeTrip(int tripCounter, double energyConsumed) throws RaiseException
	{
		super.setTripCounter(tripCounter);
		this.fuelConsumed = energyConsumed;
	}
	
	@Override
	public String toString()
	{
		return super.getSerialNumber() + " - " + super.getMake() + " - " + super.getModel() + " - " + super.getDateOfManufacture() + " - Trip counter: " + this.getTripCounter() + " - " + "GasVehicle [fuelConsumed=" + fuelConsumed + ", mileage=" + this.getMilePerUnitOfEnergy() + "]";
	}	
	
	//public static services
		public static int add(GasVehicle element) throws SQLException {
			return GasolineVehicleDB.insert(element);
		}
		
		public static int update(GasVehicle element) throws SQLException {
			return GasolineVehicleDB.update(element);
		}
		
		public static int remove(Long id) throws SQLException {
			return GasolineVehicleDB.delete(id);
		}
		
		public static GasVehicle search(Long id) throws SQLException, SQLException, NumberFormatException, RaiseException, ParseException {
			return GasolineVehicleDB.search(id);
		}
		
		public static ArrayList<GasVehicle> getData() throws SQLException, SQLException, NumberFormatException, RaiseException, ParseException {
			return GasolineVehicleDB.select();
		}
}
