package bus;

import java.util.Date;

public abstract class Vehicle implements IMileageEfficiency, java.io.Serializable{
	
	//data
	private static final long serialVersionUID = 1L;
	private Long serialNumber;
	private String make;
	private String model;
	private Date dateOfManufacture;
	private int tripCounter;
	//private EnumType type;	//GasVehicle, ElectricVehicle, none
	
	public Vehicle()
	{
		super();
		this.tripCounter = 100;
		//this.type = EnumType.Undefined;
	}
	
	//public Vehicle(Long serialNumber, String make, String model, Date dateOfManufacture, int tripCounter, EnumType type) throws RaiseException
	public Vehicle(Long serialNumber, String make, String model, Date dateOfManufacture, int tripCounter) throws RaiseException
	{
		super();
		this.setSerialNumber(serialNumber);
		this.setMake(make);
		this.setModel(model);
		this.setDateOfManufacture(dateOfManufacture);
		this.setTripCounter(tripCounter);
		//this.type = type;
	}
	
	public Long getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(Long serialNumber) throws RaiseException {
		Validator.isPositiveLong(serialNumber);
		this.serialNumber = serialNumber;
	}
	
	public String getMake() {
		return make;
	}
	public void setMake(String make) throws RaiseException {
		Validator.isAlphabetic(make);
		this.make = make;
	}
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) throws RaiseException {
		Validator.isAlphabetic(model);
		this.model = model;
	}
	
	public Date getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(Date dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	
	public int getTripCounter() {
		return tripCounter;
	}
	public void setTripCounter(int tripCounter) throws RaiseException {
		Validator.isPositiveInt(tripCounter);
		this.tripCounter = tripCounter;
	}

//	public EnumType getType() {
//		return type;
//	}
//	public void setType(EnumType type) {
//		this.type = type;
//	}

	@Override
	public double getMilePerUnitOfEnergy() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void makeTrip() {
		// TODO Auto-generated method stub
	}

	@Override
	public void makeTrip(int tripCounter, double energyConsumed) throws RaiseException {
		// TODO Auto-generated method stub
	}
	
	@Override
	public String toString() {
		//return "VehicleFactory [serialNumber=" + serialNumber + ", make=" + make + ", model=" + model + ", dateOfManufacture=" + dateOfManufacture + ", tripCounter=" + tripCounter + ", type=" + type + "]";
		return "VehicleFactory [serialNumber=" + serialNumber + ", make=" + make + ", model=" + model + ", dateOfManufacture=" + dateOfManufacture + ", tripCounter=" + tripCounter + "]";
	}
}
