package bus;

import java.util.Comparator;

public class MileageEfficiencyComparator implements Comparator<Vehicle>{
	
	public int compare(Vehicle v1, Vehicle v2)
	{
//		if(v1.getMilePerUnitOfEnergy().compareTo(v2.getMilePerUnitOfEnergy()) < 0)
//			return -1;
//		
//		else if(v1.getMilePerUnitOfEnergy().compareTo(v2.getMilePerUnitOfEnergy()) > 0) 
//			  return 1;
//		
//		        else return 0;
		
		return Double.compare(v1.getMilePerUnitOfEnergy(), v2.getMilePerUnitOfEnergy());
		
	}
}