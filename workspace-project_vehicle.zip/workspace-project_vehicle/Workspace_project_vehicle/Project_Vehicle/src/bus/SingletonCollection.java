package bus;
import java.util.ArrayList;
import java.util.Collections;

public class SingletonCollection {
	
	private static  SingletonCollection   singleInstance = null ;	

	private ArrayList<Vehicle> vehicleList  = null;
	
	 
	 public static SingletonCollection getSingleInstance() {
		 if(singleInstance == null)
		 {
			 singleInstance = new SingletonCollection();
		 }		 
		return singleInstance;
	}

	public ArrayList<Vehicle> getListOfVehicles() {
		return vehicleList;
	}

	private SingletonCollection()
	 {
		vehicleList = new ArrayList<Vehicle>();
	 }
	
    public  void add(Vehicle searchedVehicle)	{
		
		singleInstance.vehicleList.add(searchedVehicle);	
	}	
    
	public  void remove(Vehicle searchedVehicle)	{
		
		singleInstance.vehicleList.remove(searchedVehicle);	
	}

	public  void SortBySerialNumber()	{
		
		Collections.sort(singleInstance.vehicleList , new SerialNumberComparator());
	}
	
	public  void SortByMileageEfficiency()	{
		
		Collections.sort(singleInstance.vehicleList , new MileageEfficiencyComparator());
	}
	
	public  void sort(SerialNumberComparator predict)	{
		
		Collections.sort(singleInstance.vehicleList , predict);
	}	
	
	public  void sort(MileageEfficiencyComparator predict)	{
		
		Collections.sort(singleInstance.vehicleList , predict);
	}	
	
	public Vehicle search(Long key)	 {
    	
		 for( Vehicle element : singleInstance.vehicleList) {
			                            	 
			 if(element.getSerialNumber().equals(key) )	 {
				 return element ;				 
			 }
		 }		 
	   return null;	   
	 }
	
	public Vehicle search(String model)     {

        for( Vehicle element : singleInstance.vehicleList) {

            if(element.getSerialNumber().equals(model) )     {
                return element ;
            }
        }
        return null;
   }
}
