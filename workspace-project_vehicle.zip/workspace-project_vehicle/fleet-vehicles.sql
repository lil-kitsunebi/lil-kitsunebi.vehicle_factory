connect sys/sys as sysdba;
drop user fleetvehicledb cascade;

create user fleetvehicledb identified by 123;

connect sys/sys as sysdba

grant connect, resource to fleetvehicledb;
grant all privileges to fleetvehicledb;

connect fleetvehicledb/123
drop table ElectricVehicle;
drop table GasolineVehicle;

create table ElectricVehicle( 	SerialNumber number(6),  
				Make varchar2(15),
				Model varchar2(15),
				DateOfManufacture date,
				TripCounter number(3),
				KwPowerConsumed float(2));

create table GasolineVehicle( 	SerialNumber number(6), 
				Make varchar2(15),
				Model varchar2(15),
				DateOfManufacture date,
				TripCounter number(3),
				FuelConsumed float(2));

desc ElectricVehicle
desc GasolineVehicle

alter table ElectricVehicle Add constraint PK_ElecVehicle_SerialNumber CHECK(SerialNumber IS NOT NULL);
alter table GasolineVehicle Add constraint PK_GasVehicle_SerialNumber CHECK(SerialNumber IS NOT NULL);

create unique index IDX_ElecVehicle_SerialNumber on ElectricVehicle(SerialNumber);
create unique index IDX_GasVehicle_SerialNumber on GasolineVehicle(SerialNumber);

--Insert
insert into ElectricVehicle values(101, 'Audi', 'A4', (to_date('2005-05-15','YYYY-MM-DD')), 3, 4.3);
insert into ElectricVehicle values(102, 'Ford', 'Focus', (to_date('2006-06-26','YYYY-MM-DD')), 5, 3.3);
insert into ElectricVehicle values(103, 'Toyota', 'Corola', (to_date('2008-07-13','YYYY-MM-DD')), 6, 4.1);
insert into ElectricVehicle values(104, 'Tesla', 'S', (to_date('2017-12-08','YYYY-MM-DD')), 2, 5.3);
insert into ElectricVehicle values(105, 'Audi', 'R8', (to_date('2019-10-25','YYYY-MM-DD')), 3, 5.5);
insert into ElectricVehicle values(106, 'Toyota', 'Venza', (to_date('2015-07-26','YYYY-MM-DD')), 4, 3.3);
insert into ElectricVehicle values(107, 'BMW', 'X1', (to_date('2007-10-21','YYYY-MM-DD')), 7, 2.4);
insert into ElectricVehicle values(108, 'Tesla', 'Y', (to_date('2005-11-12','YYYY-MM-DD')), 6, 4.3);
insert into ElectricVehicle values(109, 'BMW', 'M3', (to_date('2006-07-17','YYYY-MM-DD')), 4, 5.3);
insert into ElectricVehicle values(110, 'Toyota', 'RAV4', (to_date('2013-05-01','YYYY-MM-DD')), 3, 5.5);
insert into ElectricVehicle values(111, 'Tesla', '3', (to_date('2010-05-02','YYYY-MM-DD')), 2, 5.3);
insert into ElectricVehicle values(112, 'BMW', 'X6', (to_date('2008-10-14','YYYY-MM-DD')), 8, 2.8);
insert into ElectricVehicle values(113, 'Toyota', 'Camry', (to_date('2007-11-18','YYYY-MM-DD')), 2, 3.9);
insert into ElectricVehicle values(114, 'Tesla', 'X', (to_date('2004-05-05','YYYY-MM-DD')), 6, 4.3);
insert into ElectricVehicle values(115, 'BMW', 'X3', (to_date('2005-08-03','YYYY-MM-DD')), 3, 3.5);
insert into ElectricVehicle values(001, 'Test', 'Test', (to_date('2000-01-01','YYYY-MM-DD')), 1, 1.2);

insert into GasolineVehicle values(201, 'Honda', 'Civic', (to_date('2005-07-10','YYYY-MM-DD')), 3, 4.1);
insert into GasolineVehicle values(202, 'Dodge', 'Ram', (to_date('2013-04-09','YYYY-MM-DD')), 5, 3.7);
insert into GasolineVehicle values(203, 'Ford', 'F-150', (to_date('2014-03-05','YYYY-MM-DD')), 6, 2.8);
insert into GasolineVehicle values(204, 'Ferari', 'Roma', (to_date('2007-11-12','YYYY-MM-DD')), 8, 4.3);
insert into GasolineVehicle values(205, 'Subaru', 'Outback', (to_date('2003-12-11','YYYY-MM-DD')), 3, 3.4);
insert into GasolineVehicle values(206, 'Jeep', 'Wrangler', (to_date('2004-10-18','YYYY-MM-DD')), 7, 2.9);
insert into GasolineVehicle values(207, 'Cadillac', 'Escalade', (to_date('2008-06-03','YYYY-MM-DD')), 5, 5.3);
insert into GasolineVehicle values(208, 'Honda', 'CR-V', (to_date('2011-07-27','YYYY-MM-DD')), 4, 4.5);
insert into GasolineVehicle values(209, 'Ford', 'Mustang', (to_date('2009-05-16','YYYY-MM-DD')), 9, 6.3);
insert into GasolineVehicle values(210, 'Dodge', 'Challenger', (to_date('2010-02-13','YYYY-MM-DD')), 8, 4.1);
insert into GasolineVehicle values(211, 'Jeep', 'Compass', (to_date('2017-01-17','YYYY-MM-DD')), 3, 3.8);
insert into GasolineVehicle values(212, 'Cadillac', 'XT6', (to_date('2015-07-15','YYYY-MM-DD')), 5, 2.3);
insert into GasolineVehicle values(213, 'Ferrari', 'Portofino', (to_date('2007-08-20','YYYY-MM-DD')), 6, 3.6);
insert into GasolineVehicle values(214, 'Subaru', 'Forester', (to_date('2006-03-07','YYYY-MM-DD')), 7, 5.6);
insert into GasolineVehicle values(215, 'Honda', 'Accord', (to_date('2005-07-04','YYYY-MM-DD')), 4, 4.7);
insert into GasolineVehicle values(002, 'Test', 'Test', (to_date('2000-01-01','YYYY-MM-DD')), 1, 1.2);

--Select
select * from ElectricVehicle;
select * from GasolineVehicle;

--Update
UPDATE ElectricVehicle SET Make = 'Test1', Model= 'Test2' WHERE SerialNumber = 001;
UPDATE GasolineVehicle SET Make = 'Test1', Model= 'Test2' WHERE SerialNumber = 002;

select * from ElectricVehicle;
select * from GasolineVehicle;

--Delete
DELETE FROM ElectricVehicle WHERE SerialNumber = 001;
DELETE FROM GasolineVehicle WHERE SerialNumber = 002;

select * from ElectricVehicle;
select * from GasolineVehicle;

--Select
SELECT * FROM ElectricVehicle WHERE SerialNumber = 101;
SELECT * FROM GasolineVehicle WHERE SerialNumber = 201;

commit;